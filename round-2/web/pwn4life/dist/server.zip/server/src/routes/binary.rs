use actix_web::{HttpResponse, get};
use log::error;
use tokio::fs;

#[get("/binary")]
pub async fn binary_route() -> HttpResponse {
    let binary_path =
        std::env::var("BINARY_PATH").expect("BINARY_PATH environment variable not set");
    let binary_data = fs::read(&binary_path).await;
    match binary_data {
        Ok(data) => HttpResponse::Ok()
            .content_type("application/octet-stream")
            .insert_header((
                "Content-Disposition",
                format!(
                    "attachment; filename=\"{}\"",
                    binary_path.split('/').last().unwrap_or("binary")
                ),
            ))
            .body(data),
        Err(err) => {
            error!("Failed to read binary file: {}", err);
            return HttpResponse::InternalServerError()
                .body("Failed to read binary file. Please create a ticket in Discord.");
        }
    }
}
